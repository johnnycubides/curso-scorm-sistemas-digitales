h# 4100 constant flash_ddir
h# 4102 constant flash_ce_n
h# 4104 constant flash_oe_n
h# 4106 constant flash_we_n
h# 4108 constant flash_byte_n
h# 410a constant flash_rdy
h# 410c constant flash_rst_n
h# 410e constant flash_a
h# 4110 constant flash_a_hi
h# 4112 constant flash_d

h# 4200 constant ps2_clk
h# 4202 constant ps2_dat
h# 4204 constant ps2_clk_dir
h# 4206 constant ps2_dat_dir
h# 4208 constant kbfifocount
h# 4210 constant kbfifo

h# 4300 constant vga_scroll
h# 4302 constant vga_spritea
h# 4304 constant vga_spriteport
h# 4306 constant vga_line
h# 4308 constant vga_addsprites

h# 4400 constant vga_spritex
h# 4402 constant vga_spritey

h# 4420 constant vga_spritec
h# 4430 constant vga_spritep

h# 4500 constant sw2_n
h# 4502 constant sw3_n

h# 5000 constant RS232_TXD
h# 5001 constant RESET_TRIGGER
h# 5100 constant ether_cs_n
h# 5101 constant ether_aen
h# 5102 constant ether_bhe_n
h# 5103 constant pb_a
h# 5104 constant ddir
h# 5105 constant pb_d
h# 5106 constant pb_rd_n
h# 5107 constant pb_wr_n
h# 5108 constant ether_rdy
h# 5109 constant ether_irq
h# 510a constant pb_a_dir

h# 6000 constant time
h# 6100 constant mult_a
h# 6102 constant mult_b
h# 6104 constant mult_p

\ Pushbuttons

h# 1 constant pb2
h# 2 constant pb3
h# 4 constant pb4
