\ For use with docforth.fs

s" ans.fs" included
