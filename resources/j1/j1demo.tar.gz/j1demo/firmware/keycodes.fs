9  constant TAB
10 constant ENTER
27 constant ESC

h# 80 constant KDEL

h# 81 constant KF1
h# 82 constant KF2
h# 83 constant KF3
h# 84 constant KF4
h# 85 constant KF5
h# 86 constant KF6
h# 87 constant KF7
h# 88 constant KF8
h# 89 constant KF9
h# 8a constant KF10
h# 8b constant KF11
h# 8c constant KF12

h# 90 constant KHOME
h# 91 constant KPGUP
h# 92 constant KPGDN
h# 93 constant KEND
h# 94 constant KLEFT
h# 95 constant KRIGHT
h# 96 constant KUP
h# 97 constant KDOWN
h# 98 constant KINS
