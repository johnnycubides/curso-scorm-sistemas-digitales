: version s" 649:659M" ;
: builddate d# 1291578086. d# -0800 ;
